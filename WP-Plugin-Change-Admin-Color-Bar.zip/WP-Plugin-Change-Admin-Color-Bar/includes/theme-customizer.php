<?php

// Registers section with WordPress customizer
function cabc_customize_register( $wp_customize ) {
	cabc_customizer_section( $wp_customize );
}